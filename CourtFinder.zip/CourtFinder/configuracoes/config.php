<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "courtfinder";

    $conexao = new mysqli($servername, $username, $password, $database);

?>